#ifndef MANAGER_H
#define MANAGER_H


#define PI 3.14


class Shape {
public:
    virtual double area() const = 0;
};

#endif // MANAGER_H
